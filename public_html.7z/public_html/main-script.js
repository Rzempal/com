// main-script.js v0.104 – Remove scroll reveal, pillars in hero

// ========== GSAP GLOBAL ==========
// GSAP jest załadowany z <script> w index.html, dostępny jako window.gsap

// ========== STATE ==========
let resizeDebounceTimer = null;

// ========== REDUCED MOTION CHECK ==========
function prefersReducedMotion() {
  return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

// ========== PILLS LOGIC ==========
function initPills() {
  const pills = document.querySelectorAll('.hub-pill');

  if (pills.length === 0) {
    console.log('ℹ️ No pills found');
    return;
  }

  pills.forEach((pill) => {
    pill.addEventListener('click', () => {
      const cardId = pill.dataset.card;
      console.log(`🔘 Pill clicked: ${cardId}`);
      showCard(cardId);
    });

    pill.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.code === 'Space') {
        e.preventDefault();
        const cardId = pill.dataset.card;
        showCard(cardId);
      }
    });
  });

  console.log('✅ Pills initialized');
}

// ========== SHOW CARD ==========
function showCard(cardId) {
  // Flash connection line
  flashPillLine(cardId);

  // Wait for flash animation peak before opening card (800ms delay)
  setTimeout(() => {
    openCard(cardId);
  }, 800);

  console.log(`📍 Showing card: ${cardId} (delayed open)`);
}

// ========== FLASH PILL LINE ==========
function flashPillLine(cardId) {
  if (!window.gsap) {
    console.warn('⚠️ GSAP not loaded, skipping flash animation');
    return;
  }

  // Special case: Robotyka has TWO lines (left and right converging)
  if (cardId === 'robotyka') {
    animateLine('pill-line-robotyka-left');
    animateLine('pill-line-robotyka-right');
    console.log(`⚡ Electric current flow for: ${cardId} (dual lines)`);
  } else {
    const lineId = `pill-line-${cardId}`;
    animateLine(lineId);
    console.log(`⚡ Electric current flow for: ${cardId}`);
  }
}

// ========== ANIMATE SINGLE LINE ==========
function animateLine(lineId) {
  const lineEl = document.getElementById(lineId);

  if (!lineEl) {
    console.warn(`⚠️ Line ${lineId} not found`);
    return;
  }

  console.log(`🔧 Animating line: ${lineId}`);

  const gsap = window.gsap;

  // Kill any existing animations on this line
  gsap.killTweensOf(lineEl);

  // Get the total length of the path for dash animation
  const pathLength = lineEl.getTotalLength();

  console.log(`📏 Path length for ${lineId}: ${pathLength}`);

  // Set up initial dash state (fully hidden)
  gsap.set(lineEl, {
    attr: {
      'stroke-dasharray': pathLength,
      'stroke-dashoffset': pathLength,
      'stroke-width': '2',
      stroke: '#48D2E7'
    },
    opacity: 0
  });

  // Create electric current flow effect with GSAP timeline
  const timeline = gsap.timeline({
    onStart: () => console.log(`▶️ Animation started for ${lineId}`),
    onComplete: () => console.log(`✅ Animation completed for ${lineId}`)
  });

  // Phase 1: Current starts flowing - reveal the path with cyan
  timeline.to(lineEl, {
    attr: {
      'stroke-dashoffset': pathLength * 0.6,
      'stroke-width': '4',
      stroke: '#48D2E7'
    },
    opacity: 0.7,
    duration: 0.3,
    ease: 'power2.in',
  }, 0);

  // Phase 2: Current accelerates - bright cyan pulse
  timeline.to(lineEl, {
    attr: {
      'stroke-dashoffset': pathLength * 0.2,
      'stroke-width': '6',
      stroke: '#6EE7FF'
    },
    opacity: 1,
    duration: 0.25,
    ease: 'power1.inOut',
  }, 0.3);

  // Phase 3: Peak current - white flash, fully revealed
  timeline.to(lineEl, {
    attr: {
      'stroke-dashoffset': 0,
      'stroke-width': '7',
      stroke: '#FFFFFF'
    },
    opacity: 1,
    duration: 0.25,
    ease: 'power2.out',
  }, 0.55);

  // Phase 4: Sustain - bright cyan, visible line
  timeline.to(lineEl, {
    attr: {
      'stroke-width': '5',
      stroke: '#6EE7FF'
    },
    opacity: 0.9,
    duration: 0.3,
    ease: 'none',
  }, 0.8);

  // Phase 5: Fade - dimmer cyan
  timeline.to(lineEl, {
    attr: {
      'stroke-width': '3',
      stroke: '#48D2E7'
    },
    opacity: 0.6,
    duration: 0.4,
    ease: 'power2.in',
  }, 1.1);

  // Phase 6: Fade out - disappear
  timeline.to(lineEl, {
    attr: {
      'stroke-width': '2',
    },
    opacity: 0,
    duration: 0.5,
    ease: 'power2.in',
  }, 1.5);
}

// ========== TYPEWRITER EFFECT ==========
function initTypewriter() {
  const subtitle = document.getElementById('heroSubtitle');
  if (!subtitle) return;

  const textEl = subtitle.querySelector('.typewriter-text');
  const cursorEl = subtitle.querySelector('.typewriter-cursor');
  if (!textEl) return;

  // Get text from translations
  const text = translations[currentLang]?.hero_subtitle || 'Jack into the digital world where code meets creativity.';
  const speed = 50; // ms per character

  let i = 0;
  textEl.textContent = '';

  function type() {
    if (i < text.length) {
      textEl.textContent += text.charAt(i);
      i++;
      setTimeout(type, speed);
    } else {
      // Typing complete - cursor keeps blinking (handled by CSS)
      console.log('✅ Typewriter complete');
    }
  }

  // Start typing
  type();
}

// ========== PAGE FADE IN ==========
function fadeInPage() {
  const body = document.body;
  const pills = document.querySelectorAll('.hub-pill');
  const heroOverlay = document.querySelector('.hero-overlay');

  if (!window.gsap) {
    // Fallback bez GSAP
    body.style.opacity = '1';
    body.style.transition = 'opacity 2s ease-out';

    // Pills stagger fallback
    pills.forEach((pill, index) => {
      setTimeout(() => {
        pill.style.opacity = '1';
        pill.style.scale = '1';
        if (pill.classList.contains('hub-pill-3')) {
          pill.style.transform = 'translate(0%, -100%) scale(1)';
        } else {
          pill.style.transform = 'translate(-100%, -100%) scale(1)';
        }
      }, 2000 + (index * 200));
    });
    // Start typewriter after fade
    setTimeout(initTypewriter, 2000);
    return;
  }

  if (prefersReducedMotion()) {
    // Reduced motion - instant display
    body.style.opacity = '1';
    pills.forEach((pill) => {
      pill.style.opacity = '1';
      const isWWW = pill.classList.contains('hub-pill-3');
      const translateX = isWWW ? '0%' : '-100%';
      pill.style.transform = `translate(${translateX}, -100%) scale(1)`;
    });
    // Start typewriter immediately
    initTypewriter();
    console.log('✅ Page instant display (reduced motion)');
    return;
  }

  // Full animation
  const gsap = window.gsap;
  const timeline = gsap.timeline();

  // Body fade in
  timeline.to(body, {
    opacity: 1,
    duration: 2,
    ease: 'power2.out',
  }, 0);

  // Hero overlay fade in from depth (scale effect)
  if (heroOverlay) {
    gsap.set(heroOverlay, { opacity: 0, scale: 0.9 });
    timeline.to(heroOverlay, {
      opacity: 1,
      scale: 1,
      duration: 1.5,
      ease: 'power2.out',
      onComplete: () => {
        // Start typewriter after hero fade in
        initTypewriter();
      }
    }, 0.3);
  }

  // Pills stagger animation (start after 1.5s)
  pills.forEach((pill, index) => {
    const isWWW = pill.classList.contains('hub-pill-3');
    const translateX = isWWW ? '0%' : '-100%';

    timeline.to(pill, {
      opacity: 1,
      scale: 1,
      transform: `translate(${translateX}, -100%) scale(1)`,
      duration: 0.6,
      ease: 'back.out(1.7)',
    }, 1.5 + (index * 0.2));
  });

  console.log('✅ Page fade in started (2s)');
}

// ========== DYNAMIC PILLS POSITIONING ==========
function positionPills() {
  const svg = document.querySelector('.hub-mesh');
  const pillsContainer = document.querySelector('.hub-pills-container');
  const pills = document.querySelectorAll('.hub-pill');

  if (!svg || !pillsContainer || pills.length === 0) {
    return;
  }

  // Get container dimensions (pills are positioned relative to this)
  const containerRect = pillsContainer.getBoundingClientRect();
  const viewBox = svg.viewBox.baseVal;

  // Calculate scale (preserveAspectRatio="xMidYMid meet" uses min scale)
  const scaleX = containerRect.width / viewBox.width;
  const scaleY = containerRect.height / viewBox.height;
  const scale = Math.min(scaleX, scaleY);

  // Calculate offset for centering SVG within container
  const offsetX = (containerRect.width - viewBox.width * scale) / 2;
  const offsetY = (containerRect.height - viewBox.height * scale) / 2;

  // Diagonal offsets for each pill (60 deg angle from vertical)
  const pillOffsets = {
    'robotyka': { x: -52, y: -30 },
    'aplikacje': { x: -52, y: -30 },
    'www': { x: 52, y: -30 },
    'android': { x: -52, y: -30 }
  };

  pills.forEach(pill => {
    const nodeX = parseFloat(pill.dataset.nodeX);
    const nodeY = parseFloat(pill.dataset.nodeY);
    const cardId = pill.dataset.card;

    if (isNaN(nodeX) || isNaN(nodeY)) {
      console.warn('⚠️ Pill missing data-node-x or data-node-y attributes');
      return;
    }

    const offset = pillOffsets[cardId] || { x: 0, y: -60 };

    // Position relative to container (not viewport)
    const posX = offsetX + ((nodeX + offset.x) * scale);
    const posY = offsetY + ((nodeY + offset.y) * scale);

    pill.style.left = `${posX}px`;
    pill.style.top = `${posY}px`;
  });

  console.log('📍 Pills positioned dynamically (scale:', scale.toFixed(3), ')');
}

// Debounced resize handler
function handleResize() {
  if (resizeDebounceTimer) {
    clearTimeout(resizeDebounceTimer);
  }

  resizeDebounceTimer = setTimeout(() => {
    positionPills();
    console.log('🔄 Pills repositioned on resize');
  }, 100);
}

// ========== COPY TO CLIPBOARD ==========
function copyToClipboard(text) {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    return navigator.clipboard.writeText(text);
  } else {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    try {
      document.execCommand('copy');
      document.body.removeChild(textarea);
      return Promise.resolve();
    } catch (err) {
      document.body.removeChild(textarea);
      return Promise.reject(err);
    }
  }
}

// Show copy feedback toast
function showCopyFeedback() {
  const toast = document.createElement('div');
  toast.className = 'copy-toast';
  toast.textContent = '✓ Skopiowano!';
  document.body.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transition = 'opacity 0.3s ease';
    setTimeout(() => {
      document.body.removeChild(toast);
    }, 300);
  }, 2000);
}

// ========== EMAIL COPY BUTTON ==========
function initEmailCopy() {
  const emailBtn = document.querySelector('.email-copy-btn');
  if (!emailBtn) return;

  emailBtn.addEventListener('click', () => {
    const email = emailBtn.dataset.email;
    if (email) {
      copyToClipboard(email)
        .then(() => {
          showCopyFeedback();
          console.log(`✓ Email copied: ${email}`);
        })
        .catch(err => {
          console.error('❌ Copy failed:', err);
        });
    }
  });

  console.log('✅ Email copy button initialized');
}

// ========== LANGUAGE TOGGLE ==========
let currentLang = 'pl';

const translations = {
  pl: {
    hub_status: 'OTWARTY NA NOWE PROJEKTY',
    pill_robotyka: 'Robotyka_',
    pill_robotyka_hero: 'SYMULACJA',
    pill_apps: 'APPS_',
    pill_www: 'WWW_',
    pill_android: 'ANDROID_',
    dev_title: 'PROGRAMOWANIE',
    enter_cta: 'WEJDZ',
    robotyka_desc: '> Zaawansowane usługi symulacji procesów produkcyjnych oraz programowanie offline robotów przemysłowych (KUKA, Fanuc, ABB). Optymalizuję przepływy pracy i zwiększam efektywność produkcji.',
    pcb_robotyka_desc: '> Przyszłość osiągów: SUV, który redefiniuje luksus. Poznaj Projekt P47 – pierwszy w historii McLarena, pięcioosobowy SUV typu coupe. Tworzony we współpracy z Forseven, ten hybrydowy potwór V8 o mocy 800 KM rzuci wyzwanie Ferrari Purosangue i Aston Martinowi DBX. Premiera rynkowa planowana jest na rok 2028. Czyste DNA sportowej jazdy, teraz w najbardziej uniwersalnej formie.',
    aplikacje_headline: 'Aplikacje webowe',
    aplikacje_desc: '> Automatyzuję to, czego nie warto robić ręcznie. Inżynierskie webappki zaprojektowane do określonych zadań biznesowych. #vibecoding',
    www_headline: 'Strony internetowe',
    www_desc: '> Projektuję nowoczesne i responsywne strony internetowe, które są wizytówką Twojej firmy. Skupiam się na estetyce, szybkości działania i intuicyjnej nawigacji.',
    android_headline: 'Twoja domowa apteczka z AI',
    android_desc: '> Technologia przestała być barierą. Stała się dźwignią dla tych, którzy mają plan.',
    pcb_android_desc: '> Nie kop w pudle. Sprawdź w telefonie. Skanuj leki aparatem, śledź daty ważności i miej wszystko pod kontrolą.',
    headline_line1: '<span class="word-cyan glitch" data-text="KOD">KOD</span> JEST',
    headline_line2: 'OSTATNIM',
    headline_line3: 'KROKIEM<span class="dot-magenta">.</span>',
    hero_scroll_cta: 'ZOBACZ, CZYM SIĘ ZAJMUJĘ',
    scroll_cta: 'ODKRYJ MOJE PROJEKTY',
    hero_subtitle: 'Jack into the digital world where code meets creativity.',
    pillars_heading: 'Symulacje robotyczne. Aplikacje. Strony internetowe.',
  },
  en: {
    hub_status: 'OPEN FOR NEW PROJECTS',
    pill_robotyka: 'Robotics_',
    pill_robotyka_hero: 'SIMULATION',
    pill_apps: 'APPS_',
    pill_www: 'WWW_',
    pill_android: 'ANDROID_',
    dev_title: 'PROGRAMMING',
    enter_cta: 'ENTER',
    robotyka_desc: '> Advanced production process simulation services and offline programming for industrial robots (KUKA, Fanuc, ABB). I optimize workflows and increase production efficiency.',
    pcb_robotyka_desc: '> Future of performance: SUV that redefines luxury. Meet Project P47 – McLaren\'s first-ever five-seater coupe SUV. Created in collaboration with Forseven, this 800 hp hybrid V8 monster will challenge Ferrari Purosangue and Aston Martin DBX. Market premiere is planned for 2028. Pure sports driving DNA, now in its most versatile form.',
    aplikacje_headline: 'Web Applications',
    aplikacje_desc: '> I automate what is not worth doing manually. Engineering webapps designed for specific business tasks. #vibecoding',
    www_headline: 'Websites',
    www_desc: '> I design modern and responsive websites that are your company\'s showcase. I focus on aesthetics, performance and intuitive navigation.',
    android_headline: 'Your home pharmacy with AI',
    android_desc: '> Technology is no longer a barrier. It has become a lever for those who have a plan.',
    pcb_android_desc: '> Don\'t dig in the box. Check your phone. Scan meds with camera, track expiration dates and keep everything under control.',
    headline_line1: '<span class="word-cyan glitch" data-text="CODE">CODE</span> IS',
    headline_line2: 'THE LAST',
    headline_line3: 'STEP<span class="dot-magenta">.</span>',
    hero_scroll_cta: 'SEE WHAT I DO',
    scroll_cta: 'DISCOVER MY PROJECTS',
    hero_subtitle: 'Jack into the digital world where code meets creativity.',
    pillars_heading: 'Robotic simulations. Applications. Websites.',
  }
};

function setLanguage(lang) {
  currentLang = lang;

  // Update all elements with data-i18n
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.dataset.i18n;
    if (translations[lang][key]) {
      el.textContent = translations[lang][key];
    }
  });

  // Update elements with data-i18n-html (innerHTML)
  document.querySelectorAll('[data-i18n-html]').forEach(el => {
    const key = el.dataset.i18nHtml;
    if (translations[lang][key]) {
      el.innerHTML = translations[lang][key];
    }
  });

  // Update toggle button text
  const langToggle = document.getElementById('lang-toggle');
  if (langToggle) {
    const langText = langToggle.querySelector('.lang-text');
    if (langText) {
      langText.textContent = lang === 'pl' ? 'EN' : 'PL';
    }
  }

  // Store preference
  localStorage.setItem('lang', lang);

  // If a card is open, translate its content too
  if (openCards.length > 0) {
    translateCardContent(document.getElementById('card-content'), lang);
  }

  console.log(`🌐 Language set to: ${lang}`);
}

function translateCardContent(container, lang) {
  if (!container) return;

  container.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.dataset.i18n;
    if (translations[lang] && translations[lang][key]) {
      el.textContent = translations[lang][key];
    }
  });

  container.querySelectorAll('[data-i18n-html]').forEach(el => {
    const key = el.dataset.i18nHtml;
    if (translations[lang] && translations[lang][key]) {
      el.innerHTML = translations[lang][key];
    }
  });
}

function initLangToggle() {
  const langToggle = document.getElementById('lang-toggle');
  if (!langToggle) return;

  // Load saved preference
  const savedLang = localStorage.getItem('lang');
  if (savedLang && (savedLang === 'pl' || savedLang === 'en')) {
    setLanguage(savedLang);
  }

  langToggle.addEventListener('click', () => {
    const newLang = currentLang === 'pl' ? 'en' : 'pl';
    setLanguage(newLang);
  });

  console.log('✅ Language toggle initialized');
}

// ========== PAGE INITIALIZATION ==========
document.addEventListener('DOMContentLoaded', () => {
  console.log('🚀 Initializing michalrapala.com...');

  if (prefersReducedMotion()) {
    console.log('⚠️ Reduced motion preference detected');
  }

  if (window.gsap) {
    console.log('✅ GSAP loaded successfully');
  } else {
    console.warn('⚠️ GSAP not found - animations will use fallback');
  }

  // Initialize page
  fadeInPage();
  initPills();
  initEmailCopy();
  initLangToggle();

  // Position pills after DOM is ready
  setTimeout(() => {
    positionPills();
  }, 100);

  // Add resize listeners
  window.addEventListener('resize', handleResize);
  window.addEventListener('orientationchange', handleResize);

  // IntersectionObserver for PCB section - reposition pills when visible
  // Fixes bug where pills don't appear on desktop scroll-snap to page 3
  const pcbSection = document.getElementById('hubMeshSection');
  if (pcbSection && 'IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          // Reposition pills when PCB section comes into view
          positionPills();
          console.log('📍 Pills repositioned on PCB section visibility');
        }
      });
    }, { threshold: 0.1 });
    observer.observe(pcbSection);
    console.log('✅ PCB section observer initialized');
  }

  // Initialize Sidebar Toggle Button
  const sidebarBtn = document.getElementById('sidebar-toggle-btn');
  if (sidebarBtn) {
    sidebarBtn.addEventListener('click', () => {
      // Restore all previously open cards
      const savedCards = JSON.parse(localStorage.getItem('openCards') || '[]');
      if (savedCards.length > 0) {
        savedCards.forEach(cardId => openCard(cardId));
      } else {
        // Fallback to default card
        openCard('robotyka');
      }
    });
  }

  console.log('✅ Initialization complete');

  // Check for deep link
  if (window.location.hash) {
    const cardId = window.location.hash.slice(1);
    if (['robotyka', 'aplikacje', 'www', 'android'].includes(cardId)) {
      console.log(`🔗 Deep link detected: ${cardId}`);
      setTimeout(() => openCard(cardId), 300);
    }
  }
});

// ========== CARD SHEET SYSTEM ==========

let openCards = []; // Array of open card IDs (stacking)
let dragState = null;

// Card data with tab names and CTA URLs
const cardData = {
  robotyka: {
    title: 'McLaren | Projekt P47',
    tabName: 'ROBOTYKA_',
    logo: 'assets/images/global/logo_robotyka.png',
    logoFallback: 'https://placehold.co/300x200/1e293b/48d2e7?text=Robotyka',
    ctaUrl: 'https://robotyka.michalrapala.com/projekty.html',
    isEng: true,
  },
  aplikacje: {
    title: 'APLIKACJE',
    tabName: 'APPS_',
    logo: 'assets/images/global/logo_app.png',
    logoFallback: 'https://placehold.co/300x200/1e293b/48d2e7?text=Aplikacje',
    ctaUrl: 'https://michalrapala.app',
    isEng: false,
  },
  www: {
    title: 'Strony internetowe',
    tabName: 'WWW_',
    logo: 'assets/images/global/logo_web_ai.png',
    logoFallback: 'https://placehold.co/300x200/1e293b/48d2e7?text=Strony+WWW',
    ctaUrl: 'https://twoja-strona.online',
    isEng: false,
  },
  android: {
    title: 'APK: Karton na leki',
    tabName: 'ANDROID_',
    logo: 'assets/images/app/Karton-AI.jpg',
    logoFallback: 'https://placehold.co/300x200/1e293b/48d2e7?text=Karton-AI',
    ctaUrl: 'https://pudelkonaleki.michalrapala.app/',
    isEng: false,
  },
};

// Detect desktop
function isDesktop() {
  return window.matchMedia('(min-width: 1025px)').matches;
}

// Open card (supports stacking multiple cards)
function openCard(id) {
  if (!cardData[id]) {
    console.error(`❌ Unknown card ID: ${id}`);
    return;
  }

  // If card already open, scroll to it
  if (openCards.includes(id)) {
    scrollToCardSection(id);
    setActiveTab(id);
    return;
  }

  console.log(`📂 Opening card: ${id}`);

  const isFirstCard = openCards.length === 0;
  openCards.push(id);

  // Mount content (animate if not first card)
  mountCardContent(id, !isFirstCard);

  // Update tabs UI
  updateCardTabs();

  // Only do sheet animation on first card
  if (isFirstCard) {
    showBackdrop(true);
    lockBodyScroll(true);

    const sheet = document.getElementById('card-sheet');
    const sidebarBtn = document.getElementById('sidebar-toggle-btn');
    if (!sheet) return;

    sheet.hidden = false;
    sheet.classList.add('is-open');

    // Hide sidebar toggle button when sidebar is open
    if (sidebarBtn) sidebarBtn.hidden = true;

    // Animation with GSAP
    if (window.gsap && !prefersReducedMotion()) {
      const gsap = window.gsap;

      if (isDesktop()) {
        gsap.fromTo(sheet,
          { x: '100%', opacity: 0 },
          { x: '0%', opacity: 1, duration: 0.5, ease: 'power2.out', force3D: true }
        );
      } else {
        gsap.fromTo(sheet,
          { y: '100%', opacity: 0 },
          { y: '0%', opacity: 1, duration: 0.5, ease: 'power2.out', force3D: true }
        );
      }
    } else {
      sheet.style.transition = 'opacity 0.3s ease';
      sheet.style.transform = isDesktop() ? 'translateX(0)' : 'translateY(0)';
      sheet.style.opacity = '0';
      sheet.offsetHeight;
      sheet.style.opacity = '1';
    }

    setTimeout(() => trapFocus(sheet), 100);
    setTimeout(() => enableDrag(sheet), 100);
  } else {
    // Scroll to newly added card
    setTimeout(() => {
      scrollToCardSection(id);
      setActiveTab(id);
    }, 100);
  }

  // Update hash and last card
  history.replaceState(null, '', `#${id}`);
  localStorage.setItem('lastCard', id);

  console.log(`✅ Card opened: ${id} (total: ${openCards.length})`);
}

// Close all cards
function closeCard() {
  if (openCards.length === 0) return;

  console.log(`📪 Closing all cards: ${openCards.join(', ')}`);

  const sheet = document.getElementById('card-sheet');
  if (!sheet) return;

  sheet.classList.remove('is-open');
  disableDrag();

  // Animation
  if (window.gsap && !prefersReducedMotion()) {
    const gsap = window.gsap;

    if (isDesktop()) {
      gsap.to(sheet, {
        x: '100%', opacity: 0, duration: 0.35, ease: 'power2.in', force3D: true,
        onComplete: () => finishClose(sheet),
      });
    } else {
      gsap.to(sheet, {
        y: '100%', opacity: 0, duration: 0.35, ease: 'power2.in', force3D: true,
        onComplete: () => finishClose(sheet),
      });
    }
  } else {
    sheet.style.transition = 'opacity 0.2s ease';
    sheet.style.opacity = '0';
    setTimeout(() => finishClose(sheet), 200);
  }
}

function finishClose(sheet) {
  sheet.hidden = true;

  // Reset inline styles
  sheet.style.transform = '';
  sheet.style.opacity = '';
  sheet.style.transition = '';

  if (window.gsap) {
    window.gsap.killTweensOf(sheet);
  }

  // Save open cards BEFORE clearing them
  if (openCards.length > 0) {
    localStorage.setItem('openCards', JSON.stringify(openCards));
  }

  unmountCardContent();
  showBackdrop(false);
  lockBodyScroll(false);

  // Do NOT change hash or scroll position - user stays where they are

  openCards = [];

  // Show sidebar toggle button when sidebar is closed (only on desktop)
  const sidebarBtn = document.getElementById('sidebar-toggle-btn');
  if (sidebarBtn && isDesktop()) {
    sidebarBtn.hidden = false;
  }

  console.log('✅ All cards closed');
}

// Carousel logic for cards
let cardCarouselTimer = null;

function initCardCarousel(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const images = container.querySelectorAll('.carousel-img');
  if (images.length < 2) return;

  let currentIndex = 0;

  function nextImage() {
    images[currentIndex].classList.remove('active');
    currentIndex = (currentIndex + 1) % images.length;
    images[currentIndex].classList.add('active');
  }

  // Clear existing timer if any
  if (cardCarouselTimer) clearInterval(cardCarouselTimer);

  // Start rotation
  cardCarouselTimer = setInterval(nextImage, 3000);
}

// Mount card content (with section wrapper for stacking)
function mountCardContent(id, animate = false) {
  const data = cardData[id];
  if (!data) return;

  const isFirstCard = openCards.length === 1;
  const isEng = data.isEng;

  // Update terminal header only for first card
  if (isFirstCard) {
    const titleEl = document.getElementById('card-title');
    if (titleEl) {
      titleEl.textContent = data.title;
    }

    const terminalDot = document.querySelector('.card-terminal-dot');
    if (terminalDot) {
      terminalDot.classList.remove('dot-yellow');
      if (id === 'android') {
        terminalDot.classList.add('dot-yellow');
      }
    }

    const prefixEl = document.getElementById('card-prefix');
    if (prefixEl) {
      prefixEl.textContent = isEng ? 'ENG://' : 'DEV://';
      prefixEl.classList.remove('prefix-eng', 'prefix-dev');
      prefixEl.classList.add(isEng ? 'prefix-eng' : 'prefix-dev');
    }
  }

  // Update topbar CTA link (always update to latest card)
  const topbarCta = document.getElementById('card-topbar-cta');
  if (topbarCta && data.ctaUrl) {
    topbarCta.href = data.ctaUrl;
    topbarCta.hidden = false;
  }

  // Hide card-media
  const mediaContainer = document.querySelector('.card-media');
  if (mediaContainer) {
    mediaContainer.style.setProperty('display', 'none', 'important');
  }

  // Create section wrapper
  const section = document.createElement('div');
  section.className = `card-section ${isEng ? 'section-eng' : 'section-dev'}`;
  section.setAttribute('data-card-section', id);

  // Add section header (visible for all stacked cards)
  const sectionHeader = document.createElement('div');
  sectionHeader.className = 'card-section-header';
  sectionHeader.innerHTML = `
    <span class="section-prefix ${isEng ? '' : 'prefix-dev'}">${isEng ? 'ENG://' : 'DEV://'}</span>
    <span class="section-title">${data.tabName.replace('_', '')}</span>
  `;
  section.appendChild(sectionHeader);

  // Clone template content
  const template = document.getElementById(`template-${id}`);
  if (template) {
    const clone = template.content.cloneNode(true);
    translateCardContent(clone, currentLang);
    section.appendChild(clone);
  }

  // Append to content area
  const contentEl = document.getElementById('card-content');
  if (contentEl) {
    contentEl.appendChild(section);

    // Animate entry from bottom if not first card
    if (animate && window.gsap && !prefersReducedMotion()) {
      window.gsap.fromTo(section,
        { y: 40, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.4, ease: 'power2.out' }
      );
    }
  }

  // Initialize carousel for robotyka
  if (id === 'robotyka') {
    setTimeout(() => initCardCarousel('robotyka-carousel'), 100);
  }

  console.log(`📝 Content mounted for: ${id} (section)`);
}

// Unmount card content
function unmountCardContent() {
  const titleEl = document.getElementById('card-title');
  if (titleEl) titleEl.innerHTML = '';

  const terminalDot = document.querySelector('.card-terminal-dot');
  if (terminalDot) {
    terminalDot.classList.remove('dot-yellow', 'dot-red');
  }

  // Reset prefix
  const prefixEl = document.getElementById('card-prefix');
  if (prefixEl) {
    prefixEl.textContent = 'SYS://';
    prefixEl.classList.remove('prefix-eng', 'prefix-dev');
  }

  const mediaContainer = document.querySelector('.card-media');
  if (mediaContainer) mediaContainer.style.display = '';

  const logoEl = document.getElementById('card-logo');
  if (logoEl) {
    logoEl.src = '';
    logoEl.alt = '';
  }

  const contentEl = document.getElementById('card-content');
  if (contentEl) contentEl.innerHTML = '';

  // Hide topbar CTA
  const topbarCta = document.getElementById('card-topbar-cta');
  if (topbarCta) {
    topbarCta.hidden = true;
    topbarCta.href = '#';
  }

  if (cardCarouselTimer) {
    clearInterval(cardCarouselTimer);
    cardCarouselTimer = null;
  }

  // Reset tabs UI
  updateCardTabs();
}

// Update card tabs UI
function updateCardTabs() {
  const tabsContainer = document.getElementById('card-tabs');
  const terminalHeader = document.getElementById('card-terminal-header');

  if (!tabsContainer || !terminalHeader) return;

  // Show tabs only when multiple cards open
  if (openCards.length > 1) {
    terminalHeader.hidden = true;
    tabsContainer.hidden = false;

    // Render tabs
    tabsContainer.innerHTML = openCards.map((id, index) => {
      const data = cardData[id];
      if (!data) return '';
      const isEng = data.isEng;
      const isActive = index === openCards.length - 1;
      return `<button class="card-tab ${isEng ? 'tab-eng' : 'tab-dev'} ${isActive ? 'active' : ''}"
                      data-tab-id="${id}"
                      aria-label="${data.tabName}">
                ${data.tabName}
              </button>`;
    }).join('');

    // Add click handlers
    tabsContainer.querySelectorAll('.card-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        const tabId = tab.getAttribute('data-tab-id');
        scrollToCardSection(tabId);
        setActiveTab(tabId);
      });
    });
  } else {
    terminalHeader.hidden = false;
    tabsContainer.hidden = true;
    tabsContainer.innerHTML = '';
  }
}

// Scroll to card section
function scrollToCardSection(id) {
  const section = document.querySelector(`[data-card-section="${id}"]`);
  const contentContainer = document.getElementById('card-content');

  if (section && contentContainer) {
    // Calculate offset of section relative to the scroll container
    const sectionTop = section.offsetTop - contentContainer.offsetTop;

    // Smooth scroll within the container
    contentContainer.scrollTo({
      top: sectionTop,
      behavior: 'smooth'
    });

    // Explicitly update last card on tab click too
    localStorage.setItem('lastCard', id);
    history.replaceState(null, '', `#${id}`);
  }
}

// Set active tab
function setActiveTab(id) {
  const tabsContainer = document.getElementById('card-tabs');
  if (!tabsContainer) return;

  tabsContainer.querySelectorAll('.card-tab').forEach(tab => {
    const tabId = tab.getAttribute('data-tab-id');
    tab.classList.toggle('active', tabId === id);
  });
}

// Show/hide backdrop
function showBackdrop(show) {
  const backdrop = document.getElementById('card-backdrop');
  if (!backdrop) return;
  backdrop.hidden = !show;
}

// Lock/unlock body scroll
function lockBodyScroll(lock) {
  if (lock) {
    const scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;
    document.documentElement.style.setProperty('--scrollbar-width', `${scrollbarWidth}px`);
    document.body.classList.add('card-open');
  } else {
    document.body.classList.remove('card-open');
    document.documentElement.style.removeProperty('--scrollbar-width');
  }
}

// Focus trap
let focusTrapActive = false;
let focusableElements = [];

function trapFocus(container) {
  if (!container) return;

  focusableElements = container.querySelectorAll(
    'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
  );

  if (focusableElements.length === 0) return;

  const firstEl = focusableElements[0];
  const lastEl = focusableElements[focusableElements.length - 1];

  firstEl.focus();
  focusTrapActive = true;

  container.addEventListener('keydown', (e) => {
    if (!focusTrapActive || e.key !== 'Tab') return;

    if (e.shiftKey) {
      if (document.activeElement === firstEl) {
        e.preventDefault();
        lastEl.focus();
      }
    } else {
      if (document.activeElement === lastEl) {
        e.preventDefault();
        firstEl.focus();
      }
    }
  });
}

// Drag/Swipe - Mobile: vertical, Desktop: horizontal (optimized with RAF)
function enableDrag(sheet) {
  const desktop = isDesktop();
  const backdrop = document.getElementById('card-backdrop'); // Cache once

  let startX = 0;
  let startY = 0;
  let currentX = 0;
  let currentY = 0;
  let isDragging = false;
  let rafId = null;

  const handleStart = (e) => {
    const target = e.target;
    if (target.closest('.card-close') || target.closest('a') || target.closest('button:not(.card-close)')) {
      return;
    }

    const clientX = e.type.includes('mouse') ? e.clientX : e.touches[0].clientX;
    const clientY = e.type.includes('mouse') ? e.clientY : e.touches[0].clientY;
    startX = clientX;
    startY = clientY;
    currentX = clientX;
    currentY = clientY;
    isDragging = true;
    sheet.classList.add('is-dragging');
    document.body.classList.add('is-dragging'); // For CSS perf optimizations
  };

  const handleMove = (e) => {
    if (!isDragging) return;

    currentX = e.type.includes('mouse') ? e.clientX : e.touches[0].clientX;
    currentY = e.type.includes('mouse') ? e.clientY : e.touches[0].clientY;

    // Use requestAnimationFrame for smooth updates
    if (rafId) cancelAnimationFrame(rafId);
    rafId = requestAnimationFrame(() => {
      if (desktop) {
        const deltaX = currentX - startX;
        if (deltaX < 0) return;

        const xPercent = (deltaX / window.innerWidth) * 100;
        sheet.style.transform = `translateX(${xPercent}%)`;

        if (backdrop) {
          backdrop.style.opacity = Math.max(0, 0.15 - (xPercent / 100) * 0.15);
        }
      } else {
        const deltaY = currentY - startY;
        if (deltaY < 0) return;

        const yPercent = (deltaY / window.innerHeight) * 100;
        sheet.style.transform = `translateY(${yPercent}%)`;

        if (backdrop) {
          backdrop.style.opacity = Math.max(0, 0.35 - (yPercent / 100) * 0.35);
        }
      }
    });
  };

  const handleEnd = () => {
    if (!isDragging) return;

    // Cancel any pending animation frame
    if (rafId) {
      cancelAnimationFrame(rafId);
      rafId = null;
    }

    isDragging = false;
    sheet.classList.remove('is-dragging');
    document.body.classList.remove('is-dragging');

    if (desktop) {
      // Desktop: horizontal swipe threshold
      const deltaX = currentX - startX;
      const deltaPercent = (deltaX / window.innerWidth) * 100;

      if (deltaPercent > 20 || deltaX > 150) {
        closeCard();
      } else {
        if (window.gsap) {
          window.gsap.to(sheet, {
            xPercent: 0,
            duration: 0.3,
            ease: 'power2.out',
          });
        } else {
          sheet.style.transform = 'translateX(0)';
        }
        if (backdrop) backdrop.style.opacity = '';
      }
    } else {
      // Mobile: vertical swipe threshold
      const deltaY = currentY - startY;
      const deltaPercent = (deltaY / window.innerHeight) * 100;
      const velocity = Math.abs(deltaY);

      if (deltaPercent > 33 || velocity > 1200) {
        closeCard();
      } else {
        if (window.gsap) {
          window.gsap.to(sheet, {
            yPercent: 0,
            duration: 0.3,
            ease: 'power2.out',
          });
        } else {
          sheet.style.transform = 'translateY(0)';
        }
        if (backdrop) backdrop.style.opacity = '';
      }
    }

    startX = 0;
    startY = 0;
    currentX = 0;
    currentY = 0;
  };

  sheet.addEventListener('mousedown', handleStart);
  sheet.addEventListener('touchstart', handleStart, { passive: true });

  document.addEventListener('mousemove', handleMove);
  document.addEventListener('touchmove', handleMove, { passive: true });
  document.addEventListener('mouseup', handleEnd);
  document.addEventListener('touchend', handleEnd);

  dragState = { handleStart, handleMove, handleEnd, sheet };

  console.log('✅ Drag enabled');
}

function disableDrag() {
  if (!dragState) return;

  const { handleStart, handleMove, handleEnd, sheet } = dragState;

  if (sheet) {
    sheet.removeEventListener('mousedown', handleStart);
    sheet.removeEventListener('touchstart', handleStart);
  }

  document.removeEventListener('mousemove', handleMove);
  document.removeEventListener('touchmove', handleMove);
  document.removeEventListener('mouseup', handleEnd);
  document.removeEventListener('touchend', handleEnd);

  dragState = null;
  focusTrapActive = false;
}

// Event listeners for card sheet
document.addEventListener('DOMContentLoaded', () => {
  const backdrop = document.getElementById('card-backdrop');
  if (backdrop) {
    backdrop.addEventListener('click', closeCard);
  }

  const closeBtn = document.querySelector('.card-close');
  if (closeBtn) {
    closeBtn.addEventListener('click', closeCard);
  }

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && openCards.length > 0) {
      closeCard();
    }
  });

  console.log('✅ Card sheet listeners initialized');
});


// ========== SCROLL INDICATOR ==========
function initScrollIndicator() {
  const indicator = document.getElementById('scrollIndicator');
  const pcbSection = document.getElementById('hubMeshSection');

  if (!indicator || !pcbSection) return;

  indicator.addEventListener('click', () => {
    pcbSection.scrollIntoView({ behavior: 'smooth' });
  });

  // Hide indicator when scrolled past hero
  const hideOnScroll = () => {
    const scrollY = window.scrollY;
    const heroHeight = window.innerHeight * 0.5;

    if (scrollY > heroHeight) {
      indicator.style.opacity = '0';
      indicator.style.pointerEvents = 'none';
    } else {
      indicator.style.opacity = '0.7';
      indicator.style.pointerEvents = 'auto';
    }
  };

  window.addEventListener('scroll', hideOnScroll, { passive: true });
  console.log('✅ Scroll indicator initialized');
}

// Initialize on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  initScrollIndicator();
});
